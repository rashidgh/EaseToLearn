import React from "react";
import NavBar from "./navBar/NavBar";
import SideBar from "./sideBar/SideBar";
import DetailsColl from "./mainbar/DetailsColl";
import DocumentsColl from "./mainbar/DocumentsColl";
import Statement from "./mainbar/Statement";
import Interview from "./mainbar/Interview";
import { BrowserRouter, Route, Routes } from "react-router-dom";

const Main = () => {
  return (
    <div>
      <NavBar />
      <div className="mainBlock">
        <SideBar />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<DetailsColl />} />
            <Route path="documents" element={<DocumentsColl />} />
            <Route path="statement" element={<Statement />} />
            <Route path="interview" element={<Interview />} />
          </Routes>
        </BrowserRouter>
      </div>
    </div>
  );
};

export default Main;
