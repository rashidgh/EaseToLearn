import React from "react";
import styles from "./side.module.css";
import { NavLink } from "react-router-dom";

const SideBar = () => {

  return (
    <section className={styles.sideBarBlock}>
      <article>
        <div>
          <div>
            <p></p>
          </div>
          <div className={styles.formBlock}>
            <h3>Link</h3>
            <span>
              Start creating a new form with wide option of the field available
            </span>
          </div>
        </div>

        <span className={styles.explore}>Explore The Following Templates:</span>
        
        <div>
          <div>
            <p></p>
          </div>
          <div className={styles.formBlock}>
            <h3>Details Collection</h3>
            <span>
              Collect Information from Candidates on their education work
              experience,contact no etc.
            </span>
          </div>
        </div>

        <div>
          <div>
            <p></p>
          </div>
          <div className={styles.formBlock}>
            <h3>Document Collection</h3>
            <span>
              Save Time and efforts. explore this this template to find a set of
              questions.
            </span>
          </div>
        </div>
        <div>
          <div>
            <p></p>
          </div>
          <div className={styles.formBlock}>
            <h3>Statement of Purpose</h3>
            <span>
              Start creating a new form with wide option of the field available
              available
            </span>
          </div>
        </div>
        <div>
          <div>
            <p></p>
          </div>
          <div className={styles.formBlock}>
            <h3>Interview Availability</h3>
            <span>
              Start creating a new form with wide option of the field available
              available
            </span>
          </div>
        </div>
      </article>
    </section>
  );
};

export default SideBar;
