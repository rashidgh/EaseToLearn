import React from 'react'
import AppCss from "./App.css"
import Main from './components/Main';



const App = () => {
  return (
    <div>
      <Main />
    </div>
  );
}

export default App